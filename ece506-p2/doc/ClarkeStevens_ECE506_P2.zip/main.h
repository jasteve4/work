/*******************************************************
			  main.h
		     Ed Gehringer 2014
		       efg@ncsu.edu
********************************************************/
int sharers(ulong);
int update(int,int,int); 
