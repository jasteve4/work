
public class PreFetch {

	public Blocks [] prefechBlocks;
	public int blockNumber;
	
	
	public PreFetch(int M, int block)
	{
		// TODO Auto-generated constructor stub
		blockNumber = block;
		prefechBlocks = new Blocks[M];
		for(int bulid = 0; bulid < M; bulid++)
		{
			prefechBlocks[bulid] = new Blocks();
		}
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		

	}



}
