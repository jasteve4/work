
public class Cache {

	public boolean debug = false;
	
	public AssocLevel [] memoryIndex;
	public PreFetch [] prefech;
	
	public boolean enablePrefech;
	public int n;
	public int m;
	public int LRU;
	int STATE = 0;
	int LOC = 1;
	int BLOCKNUMBER = 2;
	int set = 0;
	int assoc = 0;
	int blockSize = 0;
	long tag = 0;
	int index = 0;
	int blockSet = 0;
	int indexBits = 0;
	int blockBits = 0;
	int tagBits = 0;
	String cacheName;
	String debugNumber = new String();
	long instruction = 0;
	int number;
	boolean prefetchState = false;
	boolean SBAccess = false;
	int blockNumber = 0;
	int prefechCount = 0;

	
	Cache nextLevel = null;
	
	
	
	
	public int memoryTraffic = 0;
	public int read = 0;
	public int write = 0;
	public int readMiss = 0;
	public int writeMiss = 0;
	public int writeBacks = 0;
	public int SBReadMiss = 0;
	public int SBRead = 0;
	
	
	
	
	
	public Cache(int SetSize, int Assoc, int BlockSize, int N, int M, String name) 
	{
		// TODO Auto-generated constructor stub
		memoryIndex = new AssocLevel[SetSize];
		n = N;
		m = M; 
		set = SetSize;
		assoc = Assoc;
		blockSize = BlockSize;
		nextLevel = null;
		indexBits = log2(set);
		blockBits = log2(blockSize);
		tagBits = (int) (32 - indexBits - blockBits);
		cacheName = name;
		
		for(int index = 0; index < SetSize; index++)
		{
			memoryIndex[index] = new AssocLevel(Assoc, BlockSize);
		}
		if(N == 0)
		{
			enablePrefech = false;
		}
		else
		{
			enablePrefech = true;
			prefech = new PreFetch[N];
			for(int i = 0; i < N; i++)
			{
			prefech[i] = new PreFetch(M, i);
			}
		}
		
		
		
	}
		
	
	public int log2(int value)
	{
		return (short)(Math.log10(value)/Math.log10(2));
	}
	
	
	
	public void controler(long[] result) 
	{
		// TODO Auto-generated method stub
		long [] output = new long[2];
		instruction = (result[1] >> blockBits) << blockBits;
		output = processInput(instruction);
		tag = output[0];
		index = (int)output[1];
		if(result[0] == 2)
		{
			result[0] = 0;
			SBAccess = true;
		}
		
		if(result[0] == 0)
		{ 
			read();
		}
		else 
		{ 
			write();
		}
	}
	
	public long [] processInput(long input)
	{
			long [] output = new long[2];
			output[1] = (long)(( input >> blockBits) & ((long)Math.pow(2, indexBits) - 1 ));
			output[0] = (long)(( input >> indexBits + blockBits) & (long)(Math.pow(2, tagBits) - 1 ));	
			return output;
	}
		
	
	private void write() 
	{
		int result;
		long evict;
		int lru;
		long [] input = new long[2];
		write++;
		result = memoryIndex[index].search(tag);
		debugDisplay(cacheName + " write  : " + Long.toHexString(instruction) + "(tag "+ Long.toHexString(tag) +", index "+ index+ ")");
		if(result > -1)
		{
			debugDisplay(cacheName+" write hit");
			memoryIndex[index].write(result);
			debugDisplay(cacheName+ " update LRU");
		}
		else
		{
			debugDisplay(cacheName+ " miss");
			evict = recon();
			if(memoryIndex[index].memorySlot[assoc-1].dirty)
			{
				debugDisplay(cacheName+" victim: " + Long.toHexString(evict));
				writeBacks++;
				if(nextLevel == null)
				{
					memoryTraffic++;
				}
				else
				{
					input[0] = 1;
					input[1] = evict;
					nextLevel.controler(input);
				}
				if(enablePrefech)
				{
					prefechInvalid(evict);
				}
				
			}
			else
			{
				debugDisplay(cacheName+" victim: none");
				
			}
			if(enablePrefech)
			{
				prefechSearch();
				if(prefetchState)
				{
					debugDisplay(cacheName + "-SB #" + prefech[0].blockNumber + " hit, pop first entry, update LRU");
					prefechGetter(0);
				}
				else
				{
					debugDisplay(cacheName+ "-SB miss, select LRU buffer #" + prefech[0].blockNumber+", update LRU");
				}
			}		
			if(!prefetchState)
			{
				writeMiss++;	
				if(nextLevel == null)
				{
					memoryTraffic++;
				}
				else
				{
					input[0] = 0;
					input[1] = instruction;
					nextLevel.controler(input);
				}
			}
			lru = memoryIndex[index].findLRU();
			memoryIndex[index].updateMemory(tag, lru);
			debugDisplay(cacheName + " Update LRU");
			memoryIndex[index].writeUpdate();
			if(prefetchState)
			{
				prefetchHit();
				prefetchState = false;
			}
			else
			{
				preferchMiss();
				
			}
			debugDisplay(cacheName + " set dirty");
		}

	}

	
	private void read() 
	{
		int result;
		long evict;
		int lru;
		long [] input = new long[2];
		if(!SBAccess)
			read++;
		else
			SBRead++;
		debugDisplay(cacheName + " read  : " + Long.toHexString(instruction) + "(tag "+ Long.toHexString(tag) +", index "+ index+ ")");
		result = memoryIndex[index].search(tag);
		if(result > -1)
		{
			debugDisplay(cacheName+" read hit");
			memoryIndex[index].read(result);
			debugDisplay(cacheName+ " update LRU");
		}
		else
		{
			debugDisplay(cacheName+ " miss");
			evict = recon();
			if(memoryIndex[index].memorySlot[assoc-1].dirty)
			{
				debugDisplay(cacheName+" victim: " + Long.toHexString(evict));
				writeBacks++;
				if(nextLevel == null)
				{
					memoryTraffic++;
				}
				else
				{
					input[0] = 1;
					input[1] = evict;
					nextLevel.controler(input);
					
				}
				if(enablePrefech)
				{
					prefechInvalid(evict);
				}
				
			}
			else
			{
				debugDisplay(cacheName+" victim: none");
				
			}
			if(enablePrefech)
			{
				prefechSearch();
				if(prefetchState)
				{
					debugDisplay(cacheName + "-SB #" + prefech[0].blockNumber + " hit, pop first entry, update LRU");
					prefechGetter(0);
				}
				else
				{
					debugDisplay(cacheName+ "-SB miss, select LRU buffer #" + prefech[0].blockNumber+", update LRU");
				}
			
			}
			if(!prefetchState)
			{
				if(!SBAccess)
				{
					readMiss++;
				}
				else
				{
					SBReadMiss++;
				}
				
				if(nextLevel == null)
				{
					memoryTraffic++;
				}
				else
				{
					input[0] = 0;
					input[1] = instruction;
					nextLevel.controler(input);
				}
			}
			lru = memoryIndex[index].findLRU();
			memoryIndex[index].updateMemory(tag, lru);
			debugDisplay(cacheName + " Update LRU");
			if(prefetchState)
			{
				prefetchHit();
				prefetchState = false;
			}
			else
			{
				preferchMiss();
				
			}
			
		}
		SBAccess = false;
	}


	private void preferchMiss() 
	{
		// TODO Auto-generated method stub
		long [] input = new long[2];
		for(int i = 0; i < m; i++)
		{
			input[0] = 2;
			input[1] =  instruction+(i+1)*blockSize;
			if(debug)
			{
				debugDisplay(cacheName + "-SB #"+ prefech[0].blockNumber + ", prefetch "+ Long.toHexString(input[1]));
			}
			prefechSetter(input[1], 0, i);
			if(nextLevel == null)
			{
				memoryTraffic++;
			}
			else
			{
			nextLevel.controler(input);
			}
			prefechCount++;
		}
	
	}


	private void prefetchHit() 
	{
		// TODO Auto-generated method stub
		long input [] = new long[2];

		input[0] = 2;
		input[1] =  instruction+m*blockSize;
		debugDisplay(cacheName + "-SB #"+ prefech[0].blockNumber + " prefetch "+ Long.toHexString(input[1]));
		prefechSetter(input[1], 0, prefech[0].prefechBlocks.length-1);
		if(nextLevel == null)
		{
			memoryTraffic++;
		}
		else
		{
		nextLevel.controler(input);
		}
		prefechCount++;
		
	}


	private long recon() 
	{
		// TODO Auto-generated method stub
			return (index << blockBits) + ( memoryIndex[index].memorySlot[assoc-1].tag << (indexBits + blockBits));	
	}
	
	
	//  Prefetch code
	
	public void prefechInvalid(long address)
	{
		for(int i = 0; i < n; i++)
		{
			for(int v = 0; v < m; v++)
			{
				if(prefech[i].prefechBlocks[v].blocks == address)
				{
					prefech[i].prefechBlocks[v].valid = false;
				}
			}
		}	
	}
	
	
	public void prefechSearch()
	{
		for(int i = 0; i < n; i++)
		{
			if((prefech[i].prefechBlocks[0].blocks == instruction) && (prefech[i].prefechBlocks[0].valid))
			{
				prefetchState = true;
				blockNumber = prefech[i].blockNumber;
				PreFetch temp = prefech[i];
				for(int v = i; v > 0; v--)
				{
					prefech[v] = prefech[v-1];
				}
				prefech[0] = temp;
				return;
			}
		}
		
		PreFetch temp = prefech[n-1];
		for(int i = n-1; i > 0; i --)
		{
			prefech[i] = prefech[i-1];
		}
		prefech[0] = temp;
		blockNumber = prefech[0].blockNumber;
	}
	
	
	public long prefechGetter(int N)
	{
		long output = prefech[0].prefechBlocks[0].blocks;
		Blocks temp = prefech[0].prefechBlocks[0];
		for(int i  = 0; i < m-1; i++)
		{
			prefech[0].prefechBlocks[i] = prefech[0].prefechBlocks[i+1];
		}
		prefech[0].prefechBlocks[m-1] = temp;
		return output;
	}
	
	
	public void prefechSetter(long address, int N, int M)
	{
		prefech[N].prefechBlocks[M].blocks = address;
		prefech[N].prefechBlocks[M].valid = true;
	}
	
	
	public String prefechToString()
	{
		String string = new String();
		for(int i = 0; i < n; i++)
		{
			string = string + "     ";
			for(int v = 0; v < m; v++)
			{
				string = string + Long.toHexString(prefech[i].prefechBlocks[v].blocks) + "     ";
			}
			string = string + "\n";
		}
		
		return string;
	}
	
	
	public String toString()
	{
		String string = new String();
		for(int i = 0; i < memoryIndex.length; i++)
		{
			string = string + "Set " + i + ":   ";
			string=string + memoryIndex[i].toString();
		}
		return string;
	}

	
	public void debugDisplay(Object object)
	{
		if(debug)
		{
			System.out.println(object);
		}
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Cache(16, 1, 4, 3, 4, "L");
	}

		
}
