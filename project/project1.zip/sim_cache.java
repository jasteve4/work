import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;


public class sim_cache{
	
	public boolean debug = false;
	
	public boolean l2acc = false;
	public boolean vcc = false;
	public String vccAddress = new String();
	public boolean prefechMiss = false;
	
	public Cache L1;
	public Cache L2;
	
	public int blockSize;
	public int l1Size;
	public int l1Assoc;
	public int l1PreFectN;
	public int l1PreFechM;
	public int l2Size;
	public int l2Assoc;
	public int l2PreFectN;
	public int l2PreFechM;
	public String fileName;
	
	
	public int l1Set;
	public int l2Set;
	public long l1Tag;
	public long l2Tag;
	public int l1IndexBits;
	public int l2IndexBits;
	public int blockBits;
	public int l1TagBits;
	public int l2TagBits;
	
	
	public boolean enableL2 = false;
	public int INDEX = 1;
	public int TAG = 0;
	public int BLOCKOFFSET = 2; 
	
	
	public 	ArrayList<String> fileMemory = new ArrayList<String>();
	public long fileMemorySize;
	
	public int l1Reads = 0;
	public int l1Writes = 0;
	public int l1ReadHits = 0;
	public int l1WriteHits = 0;
	public int l1ReadMisses = 0;
	public int l1WriteMisses = 0;
	public int l1WriteBacks = 0;
	
	
	public int l2Reads = 0;
	public int l2Writes = 0;
	public int l2ReadHits = 0;
	public int l2WriteHits = 0;
	public int l2ReadMisses = 0;
	public int l2WriteMisses = 0;
	public int l2WriteBacks = 0;
	
	public long memoryTraff = 0;
	public int l2ReadMissesPrefech = 0;
	public int l2ReadsPrefech = 0;
	public int l1prefechCount = 0;
	public boolean prefechHit = false;
	public int currentPrefechBlock = 0;
	
	public int l2PrefetchReads = 0;
	public int l2PrefetchReadMisses = 0;
	public boolean l2prefetch = false; 
	public int l2prefechCount = 0;
	public int l2currentPrefechBlock = 0;
	
	
	
	public String l2State = " ";
	public String l2Address = " ";
	public String l2sTag = " ";
	public int l2index = 0;
	public String l2HitOrMiss = " ";
	
	

	public sim_cache(String BlockSize, String L1Size, String L1Assoc, String L1PreFectN, String L1PreFechM, String L2Size, String L2Assoc, String L2PreFectN, String L2PreFechM,  String FileName) 
	{
		// TODO Auto-generated constructor stub
		blockSize = Integer.valueOf(BlockSize);
		l1Size = Integer.valueOf(L1Size);
		l1Assoc = Integer.valueOf(L1Assoc);
		l1PreFectN = Integer.valueOf(L1PreFectN);
		l1PreFechM = Integer.valueOf(L1PreFechM);
		l2Size = Integer.valueOf(L2Size);
		l2Assoc = Integer.valueOf(L2Assoc);
		l2PreFectN = Integer.valueOf(L2PreFectN);
		l2PreFechM = Integer.valueOf(L2PreFechM);
		fileName = FileName;	
		
		
		cacheInit();
		loadTextFile();
		startProgram();
		displayResults();
		
	}

	public double round6(double to) {
		// TODO Auto-generated method stub
		BigDecimal big = BigDecimal.valueOf(to);
		big = big.movePointRight(6);
		big = big.setScale(0, RoundingMode.HALF_UP);
		big = big.movePointLeft(6);
		
		return big.doubleValue();
	}
	
	private void displayResults() 
	{

		display("===== Simulator configuration =====");
		display("BLOCKSIZE:		"+ blockSize);
		display("L1_SIZE:		"+ l1Size);
		display("L1_ASSOC: 		"+ l1Assoc);
		display("L1_PREF_N: 		" + l1PreFectN);
		display("L1_PREF_M:		" + l1PreFechM);
		display("L2_SIZE:		" + l2Size);
		display("L2_ASSOC:		" + l2Assoc);
		display("L2_PREF_N:		" + l2PreFectN);
		display("L2_PREF_M:		" + l2PreFechM);
		display("trace_file:	" + fileName);
		
		display("===== L1 contents =====");
		System.out.print(L1.toString());
		if(L1.enablePrefech)
		{
			display("===== L1-SB contents =====");
			System.out.print(L1.prefechToString());
		}
		
		if(!(L2 == null))
		{
			l2Reads = L2.read;
			l2Writes = L2.write;
			l2ReadHits = 0;
			l2WriteHits = 0;
			l2ReadMisses = L2.readMiss;
			l2WriteMisses = L2.writeMiss;
			l2WriteBacks = L2.writeBacks;
			memoryTraff = L2.memoryTraffic;
			l2PrefetchReads = L2.SBRead;
			l2PrefetchReadMisses = L2.SBReadMiss;
			l2prefechCount = L2.prefechCount;
			display("===== L2 contents =====");
			System.out.print(L2.toString());
			if(L2.enablePrefech)
			{
				display("===== L2-SB contents =====");
				System.out.print(L2.prefechToString());
			}
		}
		else
		{
			memoryTraff = L1.memoryTraffic;
			
		}
		
		double 	l1MissRate = 0.0; 	
			l1MissRate = (L1.readMiss+L1.writeMiss); 
				l1MissRate = l1MissRate/(L1.read+L1.write);
				l1MissRate = round6(l1MissRate);
		double 	l2MissRate = 0.0;
			if(!((l2ReadMisses + l2WriteMisses) == 0)&&!(L2==null))
			{
				l2MissRate = (l2ReadMisses );
				l2MissRate = l2MissRate/(l2Reads);
				l2MissRate = round6(l2MissRate);
				
			}
		

		display("===== Simulation results (raw) =====");
		display("a. number of L1 reads:                              	" + L1.read);
		display("b. number of L1 read misses:                           " + L1.readMiss);
		display("c. number of L1 writes:                                 " + L1.write);
		display("d. number of L1 write misses:                          " + L1.writeMiss);
		display("e. L1 miss rate:     					" + l1MissRate);
		display("f. number of L1 writebacks:                            " + L1.writeBacks);
		display("g. number of L1 prefetches: 				" + L1.prefechCount);
		display("h. number of L2 reads that did not originate from L1 prefetches: 	"+l2Reads);
		display("i. number of L2 read misses that did not originate from L1 prefetches:	"+l2ReadMisses);
		display("j. number of L2 reads that originated from L1 prefetches:		"+ l2PrefetchReads);
		display("k. number of L2 read misses that originated from L1 prefetches: "+ l2PrefetchReadMisses);
		display("l. number of L2 writes: " + l2Writes);
		display("m. number of L2 write misses: " + l2WriteMisses);
		display("n. L2 miss rate: " + l2MissRate);
		display("o. number of L2 writebacks: "+ l2WriteBacks);		
		display("p. number of L2 prefetches: "+ l2prefechCount);
		display("q. total memory traffic: "+ memoryTraff);
	}









	public void display(Object output)
	{
		System.out.println(output);
	}
	
	public void cacheInit()
	{	
		
		l1Set = l1Size/(l1Assoc*blockSize);
		l1Tag = (long)Math.pow(2, l1TagBits);
		
		L1 = new Cache(l1Set, l1Assoc, blockSize, l1PreFectN, l1PreFechM, "L1");
		
		if((l2Size != 0)||(l2Assoc != 0))
		{
			enableL2 = true;
		}
		
		if(enableL2)
		{
			l2Set = l2Size/(l2Assoc*blockSize);	
			L2 = new Cache(l2Set, l2Assoc, blockSize, l2PreFectN, l2PreFechM, "L2");
			L1.nextLevel = L2;
		
		}
	}
	
	
	public void loadTextFile()
	{
		try 
		{
		Scanner input = new Scanner(new File(fileName));

		       String line = input.nextLine();
		       while(input.hasNext())
		       {
				fileMemory.add(line);
		       	line = input.nextLine();
		       }
		       fileMemory.add(line);
		       input.close();
		}
		catch (IOException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
	fileMemorySize = fileMemory.size();		
		
	}	
	
	public void startProgram()
	{
		int fileIndex = 0;
		long [] result = new long[2];
		while(fileIndex <  fileMemorySize)
		{

			result = parseInput(fileMemory.get(fileIndex));
			if(debug)
			{
				display("---------------------------------------------");
				L1.debug = debug;
				L2.debug = debug;
				if(result[0] == 0)
					display("# "+ (fileIndex + 1) + " : read " + Long.toHexString(result[1]));
				else
					display("# "+ (fileIndex + 1) + " : write " + Long.toHexString(result[1]));
			}
			L1.controler(result);
			fileIndex++;
		}
	}

	
	public long [] parseInput(String inputString)
	{
		String value = inputString.substring(2);
		long [] output = new long[2];
		output[1] = Long.parseLong(value, 16);
		if(inputString.startsWith("r"))
			output[0] = 0;															// 0 is a read
		else if(inputString.startsWith("w"))
			output[0] = 1;															// 1 is a write
		return output;		
	}
		
	
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		new sim_cache(args[0],args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
	}

}
