
public class Memory {

public long tag;
public boolean vaild;
public boolean dirty;
public int [] memory;


}
