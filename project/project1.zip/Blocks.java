
public class Blocks {

	public long blocks;
	public boolean valid = true; 

}
